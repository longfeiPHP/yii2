<!DOCTYPE html>
<!-- saved from url=(0032)http://m.xiandanjia.com/download -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title><?php echo $title ; ?></title>
<link rel="stylesheet" href="/css/mobile_page.css">
<style type="text/css">
    .redcolor{
        color: #ff2d55
    }
</style>
</head>
<body>
	<div class="level-con">
    	<?php echo $content ; ?>
    </div>
</body>
</html>