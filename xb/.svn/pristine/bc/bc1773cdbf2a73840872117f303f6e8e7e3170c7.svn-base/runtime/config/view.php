<?php 
 //please do not modify this file, this file is built by app\modules\backend\models\baseConfig.php 
 return array (
  'theme' => 
  array (
    'pathMap' => 
    array (
      '@app/views' => '@app/views/tradition',
    ),
  ),
  'params' => 
  array (
    'themeColor' => 'red',
  ),
);
