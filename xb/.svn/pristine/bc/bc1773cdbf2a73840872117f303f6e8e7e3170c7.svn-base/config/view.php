<?php 
 return array (
  'theme' => 
  array (
    'pathMap' => 
    array (
      '@app/views' => '@app/views/default',
    ),
  ),
  'params' => 
  array (
    'themeColor' => 'yellow',
  ),
);
