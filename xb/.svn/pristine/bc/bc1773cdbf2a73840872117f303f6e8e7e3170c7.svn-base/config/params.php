<?php 
 return array (
    'appName' => '管理系统',
    'logo' => '@web/images/logo.png',
    'keywords' => '',
    'description' => '',
    'cacheDuration' => '-1',
    'pageSize' => '2',
    'imgcdn' =>'http://ww-mybucket.oss-cn-beijing.aliyuncs.com/',
    'level'=>['Id'=>'28','expire_time'=>3600],

);
