<?php
/**
 * Created by PhpStorm.
 * User: david
 */
return [
    '搜索'=>'Search',
    '输入关键字搜索'=>'Input a keyword search',
    '首页'=>'Home',
    '文章'=>'News',

];